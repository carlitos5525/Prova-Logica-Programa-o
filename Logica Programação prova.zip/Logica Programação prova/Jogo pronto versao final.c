#include<stdio.h>
#include<stdlib.h>
#include "colors.h"
#include <conio.h>

int main()
{
    system("color f0");
    foreground(BLACK);

    system("color f0");

    printf("\n======================================================================================================================================================== ");
    printf("\n\n================================================================  BATALHA DOS GLADIADORES ============================================================== ");
    printf("\n\n========================================================================================================================================================\n\n\n ");

    printf("\n Lista de regras: \n");
    printf("1.Partida composta por apenas 2 jogadores\n");
    printf("2.Os dois jogadores possuem 15 de vida\n");
    printf("3.Voce so pode utilizar comandos ofertados no jogo\n");
    printf("4.O jogador que fizer o outro chegar a 0 de vida primeiro vence\n");
    printf("5.Digite 1 para atacar, Digite 2 para defender e Digite 3 para andar\n");
    printf("6.Precione (Ctrl + C) a qualquer momento para encerrar o jogo\n\n\n\n");
    style(RESETALL);
    system("color f0");
    foreground(RED);
    printf("  Vida Jogador 1: [15]   \t\t\t\t\t\t\t\t\t\t\t\t\tVida Jogador 2: [15]\n\n");
    style(RESETALL);

    char vetor[50], i ; //cria��o do vetor que vai servir de tabuleiro;

    vetor[0] = 1; // Posi�ao inicial do jogador 1;
    vetor[49] = 2; // Posi��o inicial do jogador 2;

    for ( i = 1 ; i < 49 ;i++){  // preencher os vetores do tabuleiro;
        vetor[i] = '\0';
    }
    for ( i = 0; i < 50 ; i++){  // escrever o tabuleiro;
        printf("[%d]", vetor[i]);
    }
    printf("\n\n");
    int casa_atual1 = 0, casa_atual2 = 49; // casa do momento;
    int casa1, casa2 ; // salva quantas casas o jogador quer andar;
    int novacasa1, novacasa2 ; // Casas para onde o jogador vai;
    int vida1=15;
    int vida2=15;
    int defesa1=0; //variavel para ver se o jogador ativou a defesa
    int defesa2=0; //variavel para ver se o jogador ativou a defesa
    int ataque1=0; //variavel para ver se o jogador ativou o ataque
    int ataque2=0; //variavel para ver se o jogador ativou o ataque
    int andar1 = 0; //variavel para ver se o jogador ativou o andar
    int andar2 = 0; //variavel para ver se o jogador ativou o andar
    int comando1; //variavel que salva o comando do jogador 1
    int comando2; //variavel que salva o comando do jogador 2

    int inverte_jogador = 2; //variavel que inverte a ordem das jogadas.

    while(vida1 >= 0 && vida2 >= 0){ //jogo roda enquanto os jogadores estiverem vivos

    if ( inverte_jogador % 2 == 0){ //mecanismo para inverter a ordem que os jogadores jogam

        printf("\n\n\t\t\t\t \033[32mJOGADOR 1 - voce quer atacar (1), defender (2) ou andar (3)? ");
        style(RESETALL);
        scanf("%d", &comando1);
        if (comando1 == 1){
            ataque1 = 1; //ataque fica verdadeiro
        }
        else if(comando1 == 2){
            defesa1 = 1; //defesa fica verdadeiro
        }
        else if(comando1 == 3){
            andar1 = 1; //andar fica verdadeiro
            printf("\n\n \t\t\t\tJOGADOR 1 - Digite quantas casas voce quer andar de (-3 a -1 e 1 a 5) '?: ");
            scanf("%d", &casa1);
        }

        printf("\n\n\t\t\t\t \033[34mJOGADOR 2 - voce quer atacar (1), defender (2) ou andar (3)? ");
        style(RESETALL);
        scanf("%d", &comando2);
        if (comando2 == 1){
            ataque2 = 1;
        }
        else if(comando2 == 2){
            defesa2 = 1;
        }
        else if(comando2 == 3){
            andar2 = 1;
            printf("\n\n\t\t\t\tJOGADOR 2 - Digite quantas casas voce quer andar de (-3 a -1 e 1 a 5)?: ");
            scanf("%d", &casa2);

        }
         else{ //se o jogador digitar um comando invalido
            printf("\n\n\t\t\t\t ESCOLHA UMA OPCAO VALIDA ");
        }
        }



        else{
            printf("\n\n\t\t\t\t \033[34mJOGADOR 2 - voce quer atacar (1), defender (2) ou andar (3)? ");
            style(RESETALL);
            scanf("%d", &comando2);
        if (comando2 == 1){
            ataque2 = 1;
        }
        else if(comando2 == 2){
            defesa2 = 1;
        }
        else if(comando2 == 3){
            andar2 = 1;
            printf("\n\n\t\t\t\tJOGADOR 2 - Digite quantas casas voce quer andar de (-3 a -1 e 1 a 5)?: ");
            scanf("%d", &casa2);
        }
        printf("\n\n\n\t\t\t\t \033[32mJOGADOR 1 - voce quer atacar (1), defender (2) ou andar (3)? ");
        style(RESETALL);
        scanf("%d", &comando1);
        if (comando1 == 1){
            ataque1 = 1;
        }
        else if(comando1 == 2){
            defesa1 = 1;
        }
        else if(comando1 == 3){
            andar1 = 1;
            printf("\n\n \t\t\t\tJOGADOR 1 - Digite quantas casas voce quer andar de (-3 a -1 e 1 a 5) '?: ");
            scanf("%d", &casa1);
        }
        else{
            printf("\n\n\t\t\t\t ESCOLHA UMA OPCAO VALIDA ");
        }
        }

        inverte_jogador++; //incremento da variavel que inerte a ordem das jogadas

    system("cls");

    if (andar1 == 1){ //se o andar do jogador 1 for verdadeiro

                if ( casa1 >= -3 && casa1 <= 5 && casa1 !=0)   {
                    novacasa1 = casa_atual1 + casa1;  // nova casa recebe a casa atual + a casa antiga e altera dentro do vetor, fazendo o jogador movimentar.
                    if (novacasa1 < novacasa2){ // verificando se o jogador pode ir para a casa que ele ta pedindo
                        vetor[novacasa1] = vetor[casa_atual1]; //o jogador muda de posi�ao
                        vetor[casa_atual1] = 0; // Casa antiga recebe zero.
                    }
                     else
                    {
                        novacasa1 = casa_atual1; // se o jogador nao puder, ele volta para onde tava
                        printf("jogada invalida. Jogador 1, voce nao pode ultrapassar seu adversario no tabuleiro.");
                    }
                }
                else{
                    printf("\t\t\t\t\t\t\'JOGADOR 1 - VALOR INVALIDO' \n\t\t\t\t\tDIGITE UM VALOR VALIDO DE (-3 a -1 e 1 a 5) PARA ANDAR\n\n");
                }



            andar1 = 0; //reiniciando o andar

    }

    if(andar2 == 1){ //se o andar do jogador 2 for verdadeiro

                    if (casa2 >= -3 && casa2 <=5 && casa2 != 0) {
                        novacasa2 = casa_atual2 - casa2;
                        if (novacasa1 < novacasa2){ //se o jogador puder andar essa quantidade, ele anda
                            vetor[novacasa2] = vetor[casa_atual2]; //o jogador muda de posi�ao
                            vetor[casa_atual2] = 0; //a casa antiga recebe zero
                        }
                        else
                        {
                            novacasa2 = casa_atual2; //se o jogador n�o puder, ele volta para onde tava
                            printf("jogada invalida. Jogador 2, voce nao pode ultrapassar seu adversario no tabuleiro.");
                        }
                    }
                    else {
                        printf("\t\t\t\t\t\t\'JOGADOR 2 - VALOR INVALIDO' \n\t\t\t\t\tDIGITE UM VALOR VALIDO DE (-3 a -1 e 1 a 5) PARA ANDAR\n");

                    }



                andar2 = 0; //reiniciando o andar
    }



    if (ataque1 == 1){ //se o ataque do jogador 1 for verdadeiro
        if(casa_atual2 - casa_atual1 <= 3 ){ //teste para ver se os jogadores est�o a 3 casas de distancia
        printf("\n\n\t\t\t\tAtaque contra o jogador 2 efetuado com sucesso\n");
            if(defesa2 == 1){ //se a defesa do jogador 2 estiver ativado
                vida2 = vida2 - 1;
                printf("\t\t\t\t A vida do jogador 2 e: %d\n", vida2);
        }
            else{
                vida2 = vida2 - 3;
                printf("\t\t\t\t A vida do jogador 2 e: %d\n", vida2);
        }
    }

        else{
            printf("\n\n\t\t\t\t\tJOGADOR 1 - Ataque mal-sucedido\n\t\t\t\t\tVoce so pode atacar se estiver a uma distancia de 3 casas do oponente");

        }

        ataque1 = 0; //reiniciando o ataque
        defesa2 = 0; //reiniciando a defesa
    }

    if (ataque2 == 1){ //se o ataque do jogador 2 for verdadeiro

        if (casa_atual2 - casa_atual1 <= 3){ //teste para ver se os jogadores est�o a 3 casas de distancia
            printf("\n\n\t\t\t\tAtaque contra o jogador 1 bem-sucedido\n");
            if(defesa1 == 1){ //se a defesa do jogador 1 estiver ativada
                vida1 = vida1 - 1;
                printf("\t\t\t\tA vida do jogador 1 e: %d\n",vida1);
        }
            else{
                vida1 = vida1 - 3;
                printf("\t\t\t\tA vida do jogador 1 e: %d\n",vida1);
        }
    }
        else{
        printf("\n\n\t\t\t\t\tJOGADOR 2 - Ataque mal-sucedido\n\t\t\t\t\tVoce so pode atacar se estiver a uma distancia de 3 casas do oponente");}

        ataque2 = 0; //reiniciando o ataque
        defesa1 = 0; //reiniciando a defesa

    }


    printf("\n======================================================================================================================================================== ");
    printf("\n\n================================================================   BATALHA DOS GLADIADORES ============================================================== ");
    printf("\n\n========================================================================================================================================================\n\n\n ");
    printf("\n Lista de regras: \n");
    printf("1. Patida composta por apenas 2 jogadores\n");
    printf("2. Os dois jogadores possuem 15 de vida\n");
    printf("3. Voce so pode utilizar comandos ofertados no jogo\n");
    printf("4. O jogador que fizer o outro chegar a 0 de vida primeiro vence\n");
    printf("5. Digite 1 para atacar, Digite 2 para defender e Digite 3 para andar\n");
    printf("6. Precione (Ctrl + C) a qualquer momento para encerrar o jogo\n\n\n\n");
    system("color f0");
    foreground(RED);
    printf("  Vida Jogador 1: [%d] \t\t\t\t\t\t\t\t\t\t\t\t\t\tVida Jogador 2: [%d]\n\n", vida1, vida2);
    style(RESETALL);


    for ( i = 0; i < 50 ; i++){ //imprimindo o tabuleiro
        printf("[%d]", vetor[i]);}
    casa_atual1 = novacasa1; //atualizando a casa atual1
    casa_atual2 = novacasa2; //atualizando a casa atual2
    }
        printf("\n\n\n\t\t\t\t\t\t\t\t\tGAME OVER\n"); //quando a vida de um jogador chegar a 0, vai ser mostrado game over
    if (vida1 > vida2)
    {
        printf("\n\n\n\t\t\t\t\t\t\t\t\tJOGADOR 1 WIN");
    }
    else{
        printf("\n\n\n\t\t\t\t\t\t\t\t\tJOGADOR 2 WIN");
    }

    return 0;

}




